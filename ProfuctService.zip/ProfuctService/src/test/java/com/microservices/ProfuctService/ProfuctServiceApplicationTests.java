package com.microservices.ProfuctService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfuctServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
