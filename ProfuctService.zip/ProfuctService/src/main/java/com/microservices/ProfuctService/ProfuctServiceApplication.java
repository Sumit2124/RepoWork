package com.microservices.ProfuctService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfuctServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfuctServiceApplication.class, args);
	}

}
